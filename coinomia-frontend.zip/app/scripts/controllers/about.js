'use strict';

/**
 * @ngdoc function
 * @name coinomiaFrontendApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the coinomiaFrontendApp
 */
angular.module('coinomiaFrontendApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
