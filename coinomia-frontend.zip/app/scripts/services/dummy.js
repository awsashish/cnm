'use strict';

/**
 * @ngdoc service
 * @name coinomiaFrontendApp.Dummy
 * @description
 * # Dummy
 * Service in the coinomiaFrontendApp.
 */
angular.module('coinomiaFrontendApp')
  .service('Dummy', function () {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
